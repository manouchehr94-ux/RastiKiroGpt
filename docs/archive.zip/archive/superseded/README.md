---
Title: Superseded Files — README
Status: Archive
Archived: 2026-07-01
Archived By: Phase 3 — Documentation Migration
---

# Superseded Files

These files were at the root of the `docs/` folder and have been superseded by new structured documents.

## Files

| File | Was | Superseded By |
|---|---|---|
| `Rasti_Master_Roadmap_FA.md` | Persian roadmap (original) | `docs/11_Project_Knowledge/OPEN_QUESTIONS.md`, roadmap is not finalized |
| `Rasti_Production_Readiness_Audit_Review_FA.md` | Persian audit review | `docs/06_Quality_Assurance/PRODUCTION_READINESS_CHECKLIST.md` |
| `Rasti_Scalability_Roadmap_FA.md` | Persian scalability roadmap | Not yet migrated — future scope document |
| `CHANGELOG_RDOS_v1.0.md` | RDOS v1.0 changelog | `docs/CHANGELOG.md` |
| `DEPLOYMENT_GUIDE_TASK_007A.md` | Early deployment guide | `docs/09_Operations/DEPLOYMENT.md` |

## Note on FA (Farsi) Files

The Persian roadmap files (`*_FA.md`) contain valuable product vision and planning content. They have been preserved here for reference. A future task should extract the key decisions into English EKB documents with ADRs if any binding architectural decisions are contained within them.
