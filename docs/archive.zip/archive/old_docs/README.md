---
Title: Archived Old Docs — README
Status: Archive
Archived: 2026-07-01
Archived By: Phase 3 — Documentation Migration
---

# Archived Old Docs

These folders contain the original documentation structure that was superseded by the Phase 2/3 Engineering Knowledge Base.

## Why Archived

The original structure (`01_Architecture/`, `02_Development_System/`, etc.) was a collection of stub files and template structures created in earlier development phases. All valuable content has been migrated to the new EKB layers.

## What Is Here

| Folder | Content | Migrated To |
|---|---|---|
| `01_Architecture/` | Architecture stubs + DOMAIN_MODEL.md | `docs/03_Architecture/` |
| `02_Development_System/` | Dev templates, checklists | `docs/01_Human_Engineering/`, `docs/10_Prompts/` |
| `03_Business/` | Business rule stubs | `docs/04_Business_Rules/` |
| `04_Testing/` | Test rule stubs | `docs/06_Quality_Assurance/` |
| `05_Deployment/` | Deployment stubs | `docs/09_Operations/` |

## Do Not Edit

These files are archived for historical reference only. Do not edit them. Use the corresponding files in the new EKB structure.
