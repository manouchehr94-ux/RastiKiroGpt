---
Title: Archive — README
Layer: Archive
Audience: Human + AI
Status: Active
Last Verified: 2026-07-01
Source of Truth: N/A (historical)
Reusable Across Projects: No
---

# Archive

Historical, superseded, or reference-only documents.

**Do not use these for current development decisions.** Check the main docs tree first.

---

## What is Archived Here

### `old_docs/`

Documents from the original docs folder structure (pre-rebuild) that were superseded by the new organized structure.

**Why archived:** The old docs used a different folder numbering (01_Architecture, 02_Development_System, 03_Business, etc.) that did not match the new standard structure. The content was migrated to the new structure with improvements.

**New location of content:**
- `01_Architecture/` → `03_Architecture/`
- `02_Development_System/` → `02_AI_Operating_System/` + `10_Prompts/`
- `03_Business/` → `04_Business_Rules/`
- `04_Testing/` → `06_Quality_Assurance/`
- `05_Deployment/` → `09_Operations/`
- `AI/` → `02_AI_Operating_System/`

### `old_phases/`

Phase-by-phase implementation history (`06_Phases/`).

**Why archived:** Historical record. The information is now captured in ADRs and the audit reports.

### `old_ai_workspace/`

Old AI workspace framework document and related AI workspace files.

**Why archived:** Superseded by the new `02_AI_Operating_System/` layer.

### `old_audit_reports/`

This folder is NOT here. The `99_AUDIT_2026_06_30/` folder at the root of docs is kept in place as a permanent reference audit.

---

## Archive Policy

Files are archived (not deleted) to preserve:
- Historical context
- Decision history
- Reference material for future audits

If you need to restore an archived document, move it back to the main docs tree and update its metadata.

---

## Superseded Files

| Original Location | New Location | Reason |
|---|---|---|
| `docs/AI/AI_RULES.md` | `docs/02_AI_Operating_System/AI_CODE_CHANGE_RULES.md` | Expanded and reorganized |
| `docs/AI/AI_DEVELOPMENT_PROTOCOL.md` | `docs/02_AI_Operating_System/AI_SAFE_CHANGE_PROTOCOL.md` | Expanded |
| `docs/01_Architecture/SYSTEM_ARCHITECTURE.md` | `docs/03_Architecture/SYSTEM_ARCHITECTURE.md` | Expanded (was 16 lines) |
| `docs/03_Business/ORDER_RULES.md` | `docs/04_Business_Rules/ORDER_RULES.md` | Expanded (was 33 lines) |
| `docs/02_Development_System/MASTER_PROMPT.md` | `docs/10_Prompts/IMPLEMENTATION_PROMPTS.md` | Reorganized |

---

## Permanent Reference Documents (NOT Archived)

- `docs/99_AUDIT_2026_06_30/` — Complete technical audit from 2026-06-30 (kept in place)
- `docs/07_ADR/` — All ADRs (kept in place, never archived)
- `docs/08_Site_Map/` — Site map docs (kept in place)
