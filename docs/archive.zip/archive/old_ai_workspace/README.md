---
Title: Archived AI Workspace — README
Status: Archive
Archived: 2026-07-01
Archived By: Phase 3 — Documentation Migration
---

# Archived AI Workspace (Old)

This folder contains the original `docs/AI/` workspace that was the first attempt at an AI documentation system.

## Why Archived

The original AI workspace was a mixed system with prompts, policies, knowledge, standards, and workflows in a flat folder structure under `docs/AI/`. It was superseded by the `docs/02_AI_Operating_System/` layer in Phase 2.

## What Is Here

| Subfolder | Content | Migrated To |
|---|---|---|
| `AI/KNOWLEDGE/` | Domain knowledge | `docs/03_Architecture/`, `docs/04_Business_Rules/` |
| `AI/POLICIES/` | AI operating policies | `docs/02_AI_Operating_System/` |
| `AI/PROMPTS/` | Prompt templates | `docs/10_Prompts/` |
| `AI/STANDARDS/` | Coding standards | `docs/03_Architecture/DATABASE_MODEL.md`, `docs/02_AI_Operating_System/AI_CODE_CHANGE_RULES.md` |
| `AI/WORKFLOWS/` | AI workflows | `docs/05_Workflows/`, `docs/01_Human_Engineering/` |

## Do Not Use

Do not use these files directly. They are historical. The active AI Operating System is in `docs/02_AI_Operating_System/`.
